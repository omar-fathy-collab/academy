import React from "react";

const Hero = () => {
  return (
    <section className="relative w-full h-[70vh]">
      
      <img
        src="https://images.unsplash.com/photo-1503264116251-35a269479413"
        alt="Hero"
        className="w-full h-full object-cover"
      />

      
      <div className="absolute inset-0 bg-black/40"></div>

      
      <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white px-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">
          Welcome to MyApp
        </h1>
        <p className="text-lg md:text-2xl max-w-2xl">
          Your one-stop solution for amazing things .
        </p>
      </div>
    </section>
  );
};

export default Hero;
