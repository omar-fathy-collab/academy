import React from "react";

function Nav() {
  return (
    <nav className="bg-orange-500 text-white px-6 py-4 shadow-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
      
        <h1 className="text-2xl font-bold">My App</h1>

       
        <ul className="flex items-center gap-6 text-lg">
          <li className="hover:text-gray-200 cursor-pointer transition">Home</li>
          <li className="hover:text-gray-200 cursor-pointer transition">About</li>
          <li className="hover:text-gray-200 cursor-pointer transition">Services</li>
          <li className="hover:text-gray-200 cursor-pointer transition">Contact</li>
        </ul>
      </div>
    </nav>
  );
}

export default Nav;
