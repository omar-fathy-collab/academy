import { useState } from "react";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState(""); 
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  
  

  const handleSubmit = (e) => {
    e.preventDefault(); 

    if (!username || !password) {
      setMessage("Please fill in all fields");
      return;
    }

    localStorage.setItem("username", username);
    localStorage.setItem("password", password);

    setMessage("Login Successful");
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100">
      <form
        onSubmit={handleSubmit}
        className="bg-white p-6 rounded-2xl shadow-md w-80">

        <h2 className="text-xl font-semibold mb-4 text-center">Login</h2>

        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="w-full mb-3 p-2 border rounded"/>

        <input
          type="email"
          placeholder="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full mb-3 p-2 border rounded"/>


        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full mb-3 p-2 border rounded"/>

        <button
          type="submit"
          className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">Login</button>

        {message && (
          <p className="mt-3 text-center text-sm text-green-600">{message}</p>
        )}
      </form>
    </div>
  );
}
