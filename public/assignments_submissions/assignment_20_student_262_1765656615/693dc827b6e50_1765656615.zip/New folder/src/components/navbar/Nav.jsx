import { useState } from "react";
import { Home, User, Phone } from "lucide-react";

const navItems = [
  { label: "Home", icon: Home, path: "/" },
  { label: "About", icon: User, path: "/about" },
  { label: "Contact", icon: Phone, path: "/contact" },
];

const Nav = () => {
  const [activeItem, setActiveItem] = useState("Home");

  return (
    <nav className="w-full h-16 bg-amber-500 shadow-md fixed top-0 left-0 z-50">
      <div className="container mx-auto px-4 h-full flex items-center justify-between">
        
        {/* Logo */}
        <a href="/" className="text-xl font-bold text-white">
          MyApp
        </a>

        {/* Menu */}
        <ul className="hidden md:flex items-center gap-4">
          {navItems.map((item) => (
            <li key={item.label}>
              <a
                href={item.path}
                onClick={() => setActiveItem(item.label)}
                className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition
                  ${
                    activeItem === item.label
                      ? "bg-amber-700 text-white"
                      : "text-white hover:bg-amber-600"
                  }`}
              >
                <item.icon size={18} />
                <span>{item.label}</span>
              </a>
            </li>
          ))}
        </ul>

      </div>
    </nav>
  );
};

export default Nav;
