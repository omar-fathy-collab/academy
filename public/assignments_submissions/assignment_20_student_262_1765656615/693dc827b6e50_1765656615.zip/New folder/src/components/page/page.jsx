const Home = () => {
  const banner = "url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee"

  return (
    <div
      className="relative w-full h-[95vh] bg-cover bg-center flex items-center justify-center"
      style={{
        backgroundImage:
          "url(${banner})",
      }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black opacity-50"></div>

      {/* Text Content */}
      <div className="relative z-10 text-center text-white p-4">
        <h1 className="text-4xl md:text-5xl font-bold">
          Welcome to MyApp
        </h1>
        <p className="mt-4 text-lg md:text-xl">
          Your one-stop solution for amazing things.
        </p>
      </div>
    </div>
  );
};

export default Home;