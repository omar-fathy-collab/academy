import React from 'react'
import Nav from './components/navbar/Nav'
import Home from './components/page/page'

const App = () => {
  return (
    <>
    <Nav />
    <Home />
    </>
  )
}

export default App
